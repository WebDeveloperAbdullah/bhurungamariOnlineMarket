
<footer>
	<div class="container">
		<div class="copyright">
		  <i >unique zone&copy right 2021</i>
		
	</div><!-------copyright-end----------------->
		
	</div>
		

	
	
		</div>
		
	</div>
		
	</footer><!------footer-area-end-here------>
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.tiny.cloud/1/s7z5ydu9x5j46z75lidtpf5d75t12kddz3o9g7wwrui8skw5/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="https://cdn.tiny.cloud/1/s7z5ydu9x5j46z75lidtpf5d75t12kddz3o9g7wwrui8skw5/tinymce/5/jquery.tinymce.min.js" referrerpolicy="origin"></script>
  
   
    <script>

      $('textarea#tiny').tinymce({
        height: 190,
        menubar: false,
        plugins: [
          'advlist autolink lists link image charmap print preview anchor',
          'searchreplace visualblocks code fullscreen',
          'insertdatetime media table paste code help wordcount'
        ],
        toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help'
      });
      
    </script>


  <script src="assets/vendor/typed.js/typed.min.js"></script>

	<script src="js/jquery.min.js"></script>
	 <script src="js/bootstrap.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/wow.min.js"></script>
     <script>
        new WOW().init();
    </script>




<script type="text/javascript" src="javaScript.js"></script>
 <script src="js/all.min.js"></script>

</body>
</html>