<?php 
include("inclued/header.php");


 ?>
            <div class="col-9">
            	<div class="min_conteant">

            		
            	</div>
            	
            </div>

        </div>
    </div>


 	<?php 

include("inclued/footer.php");


 	 ?>	
 	